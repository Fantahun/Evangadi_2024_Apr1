// console.log("connected");
let generatedNumber = $("#generatedNumber");

let generate = $("#generate");

let generateNumbers = function () {
  let minimum = $("#minimum").val(); //''
  let maximum = $("#maximum").val(); // ''

  let min = Number(minimum);
  let max = Number(maximum);

  console.log(minimum);
  console.log(maximum);

  //   let generatedNumber = minimum + Math.random() * (maximum - minimum);

  let genNumber = min + Math.random() * (max - min);

  let rounded = Math.round(genNumber);

  generatedNumber.text(rounded);

  console.log(rounded);
};

generate.on("click", generateNumbers);

