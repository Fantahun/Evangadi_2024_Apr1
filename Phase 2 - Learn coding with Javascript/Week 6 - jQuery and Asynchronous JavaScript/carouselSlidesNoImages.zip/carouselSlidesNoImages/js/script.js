const slideWidth = $(".slide").width();
const slideDuration = 3000; // Time interval for each slide

// Function to move the slides
function moveSlides() {
	$(".slides").animate(
		{
			"margin-left": -slideWidth,
		},
		1000,
		function () {
			// Move the first slide to the end
			$(".slides .slide:first").appendTo(".slides");
			// Reset the margin
			$(".slides").css("margin-left", 0);
		}
	);
}

// Set an interval to move the slides
setInterval(moveSlides, slideDuration);
