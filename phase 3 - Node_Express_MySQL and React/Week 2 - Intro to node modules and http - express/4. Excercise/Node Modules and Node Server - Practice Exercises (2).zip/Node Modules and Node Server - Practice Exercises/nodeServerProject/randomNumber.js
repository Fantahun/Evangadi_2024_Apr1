function random(){
    return Math.random();
}

let randNum = random();
console.log(randNum);

module.exports.random = random;